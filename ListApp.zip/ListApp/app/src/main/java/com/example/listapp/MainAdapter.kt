package com.example.listapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.album_row.view.*
import android.content.Intent


class MainAdapter(val data: Model): RecyclerView.Adapter<CustomViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CustomViewHolder {
    val layoutInflater = LayoutInflater.from(parent.context)
    val callForRow = layoutInflater.inflate(R.layout.album_row, parent, false)
    return CustomViewHolder(callForRow)
    }

    override fun getItemCount(): Int {
        return data.feed.results.count()
    }

    override fun onBindViewHolder(holder: CustomViewHolder, position: Int) {
        holder.view.textViewId.text = data.feed.results[position].name
        holder.view.textViewArtistId.text = data.feed.results[position].artistName
        val albumImgView = holder.view.imageViewId
        Picasso.with(holder.view.context).load(data.feed.results[position].artworkUrl100).into(albumImgView)

        holder.album = data.feed.results[position]
    }
}
class CustomViewHolder(val view: View, var album: Result? = null): RecyclerView.ViewHolder(view){
    init {
        view.setOnClickListener{
            val intent = Intent(view.context, AlbumDetailActivity::class.java)
            intent.putExtra("albumName", album?.name)
            intent.putExtra("artistName", album?.artistName)
            intent.putExtra("albumURL", album?.artworkUrl100)
            intent.putExtra("genre", album?.genres?.get(0)?.name)
            intent.putExtra("release", album?.releaseDate)
            intent.putExtra("albumApStore", album?.url)
            intent.putExtra("artistApStore", album?.artistUrl)
            intent.putExtra("copyright", album?.copyright)

            view.context.startActivity(intent)
        }
    }
}