package com.example.listapp

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_album_datail.*

@Suppress("NULLABILITY_MISMATCH_BASED_ON_JAVA_ANNOTATIONS")
class AlbumDetailActivity: AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_album_datail)
        albumNameId.text = intent.getStringExtra("albumName")
        artistNameId.text = intent.getStringExtra("artistName")
        val albumArt = intent.getStringExtra("albumURL")
        Picasso.with(this).load(albumArt).into(albumArtId)
        releaseId.text = intent.getStringExtra("release")
        genreId.text = intent.getStringExtra("genre")
        copyrightId.text = intent.getStringExtra("copyright")

        albumApId.setOnClickListener{
            openNewTabWindow(intent.getStringExtra("albumApStore"), this)
        }

        artistApId.setOnClickListener{
            openNewTabWindow(intent.getStringExtra("artistApStore"), this)
        }
    }

    fun openNewTabWindow(urls: String, context: Context) {
        val uris = Uri.parse(urls)
        val intents = Intent(Intent.ACTION_VIEW, uris)
        val b = Bundle()
        b.putBoolean("new_window", true)
        intents.putExtras(b)
        context.startActivity(intents)
    }
}