package com.example.listapp


import com.google.gson.annotations.SerializedName

data class Model(
    @SerializedName("feed")
    val feed: Feed
)