package com.example.listapp
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.GsonBuilder
import kotlinx.android.synthetic.main.activity_main.*
import okhttp3.*
import java.io.IOException

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        recyclerViewId.layoutManager = LinearLayoutManager(this)
        fetchJson()
    }

    fun fetchJson(){
        val url = getString(R.string.jsonFile)

        val request = Request.Builder().url(url).build()

        val client = OkHttpClient()
        client.newCall(request).enqueue(object : Callback{
            override fun onResponse(call: Call, response: Response) {
                val body = response.body()?.string()
                println(body)

                val gson = GsonBuilder().create()
                val feed = gson.fromJson(body, Model::class.java)

                runOnUiThread{
                    recyclerViewId.adapter = MainAdapter(feed)
                }

           }
            override fun onFailure(call: Call, e: IOException) {
               println("Failed to execute request.")
            }
        })
    }
}

