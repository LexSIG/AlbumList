package com.example.listapp


import com.google.gson.annotations.SerializedName

data class Link(
    @SerializedName("alternate")
    val alternate: String,
    @SerializedName("self")
    val self: String
)