package com.example.listapp


import com.google.gson.annotations.SerializedName

data class Author(
    @SerializedName("name")
    val name: String,
    @SerializedName("uri")
    val uri: String
)